# Redline Pursuit – Android (offline APK project)

A complete Android Studio / Gradle project that wraps the game in a full-screen, landscape-locked WebView.
All game files live inside the app (`app/src/main/assets/www/`). The finished app has **no INTERNET
permission**, so it runs 100 % offline. Garage, cash and your control settings are saved on the phone.

## Before you start – read this
* The only outside file the game needs is **three.js r128**. The build downloads it **once** (during the
  build, not on the phone) and packs it into the APK. So the *build* needs internet; the APK never does.
* This project could not be compiled where it was written (no Android SDK / internet there). The game code,
  manifest, Gradle files and Java were each checked, but the very first real build is the real test.
  If Gradle prints an error, send it to me and I will fix it.

## Easiest: build in the cloud (nothing to install)
1. Create a free account at github.com and a new **empty repository**.
2. **Unzip this project first**, then upload everything from inside the folder (drag & drop works in the browser).
3. **Check the repo shows a `.github` folder.** Browsers often skip hidden folders when uploading. If it is missing, add the
   workflow by hand (30 seconds): **Add file ▸ Create new file**, type the name `.github/workflows/build-apk.yml`
   (typing the slashes creates the folders), paste the contents of `github-workflow-build-apk.yml.txt`, then **Commit changes**.
4. Open the **Actions** tab. The build starts by itself after that commit (or pick **Build APK ▸ Run workflow**). Wait ~4-6 minutes.
5. Open the finished run ▸ **Artifacts** ▸ download **Redline-Pursuit-APK** ▸ unzip ▸ `app-debug.apk`.

If Actions says workflows are disabled, click **I understand my workflows, go ahead and enable them**.

## Android Studio (Windows / Mac / Linux)
1. Install Android Studio, choose **Open** and pick this folder. Let Gradle sync (needs internet the first time).
2. **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**.
3. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Command line
Needs JDK 17, the Android SDK (platform 34) and Gradle 8.7:
```
gradle assembleDebug
```

## Install on your phone
Copy `app-debug.apk` to the phone → open it → allow **Install unknown apps** for your file manager/browser when asked.
(Uninstalling the app deletes its saved progress.)

## A signed release build (for sharing / Google Play)
1. Make a key once (keep the file and passwords safe, never lose them):
   `keytool -genkeypair -v -keystore redline.jks -alias redline -keyalg RSA -keysize 2048 -validity 10000`
2. Put `redline.jks` next to `settings.gradle` and add `keystore.properties` beside it:
   ```
   storeFile=redline.jks
   storePassword=YOUR_PASSWORD
   keyAlias=redline
   keyPassword=YOUR_PASSWORD
   ```
3. `gradle assembleRelease` (APK) or `gradle bundleRelease` (AAB for Google Play).

## Customising
* App name: `app/src/main/res/values/strings.xml`.   * Package id: `applicationId` + `namespace` in `app/build.gradle`.
* Icon: replace the `ic_launcher.png` files in `app/src/main/res/mipmap-*`.
* Game: edit `app/src/main/assets/www/index.html` (it is the same game file as the browser version).

## Troubleshooting
* **"Could not download three.js"** – save https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js as
  `app/src/main/assets/www/three.min.js`, then build again.
* **Black screen in the app** – `three.min.js` was missing from the build; rebuild after step above.
* **"SDK location not found"** – open the project once in Android Studio, or create `local.properties` with `sdk.dir=/path/to/Android/sdk`.
